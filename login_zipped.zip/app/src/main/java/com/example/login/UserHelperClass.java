package com.example.login;

public class UserHelperClass {
    String empId,password,name ,phoneNo;

    public UserHelperClass() {
    }

    public UserHelperClass(String empId, String password, String name, String phoneNo) {
        this.empId = empId;
        this.password = password;
        this.name = name;
        this.phoneNo = phoneNo;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }
}
