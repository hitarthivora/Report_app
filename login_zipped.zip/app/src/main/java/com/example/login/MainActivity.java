package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    Button mStartReport;
    //TextView mUser,mUid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*mUser = findViewById(R.id.user);
        mUid = findViewById(R.id.uid);
        showUserAllDetails();*/

        mStartReport = findViewById(R.id.startReport);
        mStartReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "LOADING...",Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(),Question_T1.class));

            }
        });

    }

    /*private void showUserAllDetails() {
        Intent i=getIntent();
        String user_name = i.getStringExtra("name");
        String user_uid = i.getStringExtra("userId");
        String user_email = i.getStringExtra("email");
        mUser.setText(user_name);
        mUid.setText(user_email);

    }*/


    public void logout(View view){
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(getApplicationContext(),Login.class));
        finish();
    }
}
