package com.example.login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

import static java.lang.Character.isAlphabetic;
import static java.lang.Character.isDigit;


public class Register extends AppCompatActivity {
    EditText mFullName,mEmployeeId,mPhone;
    public TextInputLayout mPassword;
    Button mRegistrationBtn;
    TextView mLoginBtn;
    ProgressBar mProgressBar;
    FirebaseAuth fAuth;
    FirebaseDatabase rootNode;
    DatabaseReference reference;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mFullName = findViewById(R.id.fullname);
        mEmployeeId = findViewById(R.id.employeeid);
        mPassword = findViewById(R.id.et_password);
        mPhone = findViewById(R.id.phone);
        mRegistrationBtn = (Button) findViewById(R.id.register);
        mLoginBtn = findViewById(R.id.logintext);
        fAuth = FirebaseAuth.getInstance();
        mProgressBar = findViewById(R.id.register_progressBar);
        if(fAuth.getCurrentUser() != null)
        {
            startActivity(new Intent(getApplicationContext(),MainActivity.class));
            finish();
        }

        mRegistrationBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String empid = mEmployeeId.getText().toString().trim();
                String pswd = mPassword.getEditText().getText().toString().trim();
                final String fn = mFullName.getText().toString().trim();
                String ph = mPhone.getText().toString().trim();
                //String NoWhiteSpace = "(?=\\s+$)";

                if(TextUtils.isEmpty(fn))
                {
                    mFullName.setError("Name is Required !!");
                    return;
                }
                if(TextUtils.isEmpty(ph))
                {
                    mPhone.setError("Employee Id is Required !!");
                    return;
                }
                if(TextUtils.isEmpty(empid))
                {
                    mEmployeeId.setError("Employee Id is Required !!");
                    return;
                }


                if(TextUtils.isEmpty(pswd))
                {
                    mPassword.setError("Password is Required !!");
                    return;
                }
                else if(pswd.length() < 8) {
                    mPassword.setError("Password must contain 8 characters !!");
                    return;
                }
                else if(!isAlphabetic(pswd.charAt(0))) {
                    mPassword.setError("Password must begin with an Alphabet !!");
                    return;
                }
                else
                    mPassword.setError(null);


                mProgressBar.setVisibility(View.VISIBLE);

                rootNode = FirebaseDatabase.getInstance();
                reference = rootNode.getReference("users");
                UserHelperClass newUser = new UserHelperClass(empid,pswd,fn,ph);
                reference.child(ph).setValue(newUser);
                Toast.makeText(Register.this, "Creating Your Profile...",Toast.LENGTH_SHORT).show();


                fAuth.createUserWithEmailAndPassword(empid,pswd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(Register.this, "User Created !!",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        }
                        else
                        {
                            Toast.makeText(Register.this, "ERROR ! "+ Objects.requireNonNull(task.getException()).getMessage(),Toast.LENGTH_SHORT).show();
                            mProgressBar.setVisibility(View.GONE);
                        }
                    }
                });



            }
        });



        mLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Login.class));
            }
        });

    }
}
