package com.example.login;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class Question_T2 extends AppCompatActivity {
    EditText mComment4, mComment5;
    Button mYes4, mNo4, mYes5, mNo5, mNext,mPrev;
    Button imgButton, imgButton1;
    Integer REQUEST_CAMERA = 1, SELECT_FILE = 0, REQUEST_CAMERA1 = 1, SELECT_FILE1 = 0, flag;
    LinearLayout layout, layout1;
    ImageView imageView, imageView1;
    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question__t2);
        mComment4 = findViewById(R.id.comment4);
        mComment5 = findViewById(R.id.comment5);
        mYes4 = findViewById(R.id.yes4);
        mYes5 = findViewById(R.id.yes5);
        mNo4 = findViewById(R.id.no4);
        mNo5 = findViewById(R.id.no5);
        mNext = findViewById(R.id.page3);
        mPrev = findViewById(R.id.page1);
        String cm4 = mComment4.getText().toString().trim();
        String cm5 = mComment5.getText().toString().trim();
        final String[] ans4 = {""};
        final String[] ans5 = {""};
        imgButton = findViewById(R.id.btn_captureImage);
        layout = findViewById(R.id.layout);
        imgButton1 = findViewById(R.id.btn_captureImage1);
        layout1 = findViewById(R.id.layout1);

        imgButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag = 0;
                SelectImage();
            }

        });
        imgButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag = 1;
                SelectImage();
            }

        });


        mYes4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ans4[0] = "yes";
            }
        });
        mNo4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ans4[0] = "no";
            }
        });


        mYes5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ans5[0] = "yes";
            }
        });
        mNo5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ans5[0] = "no";
            }
        });

        if (cm4.length() > 50) {
            mComment4.setError("Comment may contain 50 characters only !!");
            return;
        }
        if (cm5.length() > 50) {
            mComment5.setError("Comment may contain 50 characters only !!");
            return;
        }


        mNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(ans4[0])) {
                    mComment4.setError("Select either Yes or No !!");
                    return;
                }
                if (TextUtils.isEmpty(ans5[0])) {
                    mComment5.setError("Select either Yes or No!!");
                    return;
                }

                Intent ix = getIntent();
                String a1 = ix.getStringExtra("ans1");
                String a2 = ix.getStringExtra("ans2");
                String a3 = ix.getStringExtra("ans3");

                Toast.makeText(Question_T2.this, "Saving Answers...", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), Question_T3.class);
                i.putExtra("ans1", a1);
                i.putExtra("ans2", a2);
                i.putExtra("ans3", a3);
                i.putExtra("ans4", ans4[0]);
                i.putExtra("ans5", ans5[0]);
                startActivity(i);
            }
        });
        mPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Question_T1.class);
                startActivity(i);
            }
        });

    }

    public void SelectImage() {
        final CharSequence[] items = {"Camera", "Gallery", "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(Question_T2.this);
        builder.setTitle("Add Image");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (items[i].equals("Camera")) {

                    Intent intent1 = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent1, REQUEST_CAMERA);
                    if (flag == 0)
                        imageView = new ImageView(Question_T2.this);
                    else if (flag == 1)
                        imageView1 = new ImageView(Question_T2.this);

                } else if (items[i].equals("Gallery")) {
                    Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    intent.setType("image/*");
                    startActivityForResult(intent.createChooser(intent, "Select File"), SELECT_FILE);
                } else if (items[i].equals("Cancel")) {
                    dialogInterface.dismiss();
                }
            }
        });
        builder.show();
    }

    public void addView(ImageView imageView, int width, int height) {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(width, height);
        layoutParams.setMargins(0, 10, 0, 10);
        imageView.setLayoutParams(layoutParams);
        if (imageView.getParent() != null) {
            ((ViewGroup) imageView.getParent()).removeView(imageView); // <- fix
        }
        if (flag == 0)
            layout.addView(imageView);
        else if (flag == 1)
            layout1.addView(imageView);



    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_CAMERA) {
                bitmap = (Bitmap) data.getExtras().get("data");
                if (flag == 0) {
                    imageView.setImageBitmap(bitmap);
                    addView(imageView, 200, 200);
                } else if (flag == 1) {
                    imageView1.setImageBitmap(bitmap);
                    addView(imageView1, 200, 200);
                }


            } else if (requestCode == SELECT_FILE) {
                Uri selectImageUri = data.getData();
                if (flag == 0) {
                    imageView.setImageURI(selectImageUri);
                    addView(imageView, 200, 200);
                } else if (flag == 1) {
                    imageView1.setImageURI(selectImageUri);
                    addView(imageView1, 200, 200);
                }

            }
        }

    }
}
