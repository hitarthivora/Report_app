package com.example.login;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Question_T1 extends AppCompatActivity {
    EditText mComment1,mComment2,mComment3;
    Button mYes1,mNo1,mYes2,mNo2,mYes3,mNo3,mNext;
    Button imgButton,imgButton1,imgButton2;
    ImageView imageView,imageView1,imageView2;
    Integer REQUEST_CAMERA=1, SELECT_FILE=0,REQUEST_CAMERA1=1, SELECT_FILE1=0,REQUEST_CAMERA2=1, SELECT_FILE2=0,flag;
    LinearLayout layout,layout1,layout2;
    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question__t1);
        mComment1 = findViewById(R.id.comment1);
        mComment2 = findViewById(R.id.comment2);
        mComment3 = findViewById(R.id.comment3);
        mYes1 = findViewById(R.id.yes1);
        mYes2 = findViewById(R.id.yes2);
        mYes3 = findViewById(R.id.yes3);
        mNo1 = findViewById(R.id.no1);
        mNo2 = findViewById(R.id.no2);
        mNo3 = findViewById(R.id.no3);
        mNext = findViewById(R.id.page2);
        String cm1 = mComment1.getText().toString().trim();
        String cm2 = mComment2.getText().toString().trim();
        String cm3 = mComment3.getText().toString().trim();
        final String[] ans1 = {""};
        final String[] ans2 = {""};
        final String[] ans3 = {""};
        imgButton = findViewById(R.id.btn_captureImage);
        layout = findViewById(R.id.layout);
        imgButton1 = findViewById(R.id.btn_captureImage1);
        layout1 = findViewById(R.id.layout1);
        imgButton2 = findViewById(R.id.btn_captureImage2);
        layout2 = findViewById(R.id.layout2);



        imgButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=0;
                SelectImage();
            }

        });
        imgButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=1;
                SelectImage();
            }

        });
        imgButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=2;
                SelectImage();
            }

        });

        mYes1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ans1[0] = "yes";
            }
        });
        mNo1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ans1[0] = "no";
            }
        });


        mYes2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ans2[0] = "yes";
            }
        });
        mNo2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ans2[0] = "no";
            }
        });


        mYes3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ans3[0] = "yes";
            }
        });
        mNo3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ans3[0] = "no";
            }
        });


        if (cm1.length() > 50) {
            mComment1.setError("Comment may contain 50 characters only !!");
            return;
        }
        if (cm2.length() > 50) {
            mComment2.setError("Comment may contain 50 characters only !!");
            return;
        }
        if (cm3.length() > 50) {
            mComment3.setError("Comment may contain 50 characters only !!");
            return;
        }

        mNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(ans1[0])) {
                    mComment1.setError("Select either Yes or No !!");
                    return;
                }
                if (TextUtils.isEmpty(ans2[0])) {
                    mComment2.setError("Select either Yes or No!!");
                    return;
                }
                if (TextUtils.isEmpty(ans3[0])) {
                    mComment3.setError("Select either Yes or No is Required !!");
                    return;
                }
                Toast.makeText(Question_T1.this, "Saving Answers...", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), Question_T2.class);
                i.putExtra("ans1", ans1[0]);
                i.putExtra("ans2", ans2[0]);
                i.putExtra("ans3", ans3[0]);
                startActivity(i);
            }
        });

    }


    public void SelectImage() {
        final CharSequence[] items={"Camera","Gallery","Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(Question_T1.this);
        builder.setTitle("Add Image");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if(items[i].equals("Camera")){

                    Intent intent1 = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent1,REQUEST_CAMERA);
                    if(flag==0)
                        imageView = new ImageView(Question_T1.this);
                    else if(flag==1)
                        imageView1 = new ImageView(Question_T1.this);
                    else if(flag==2)
                        imageView2 = new ImageView(Question_T1.this);

                }
                else if(items[i].equals("Gallery")){
                    Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    intent.setType("image/*");
                    startActivityForResult(intent.createChooser(intent, "Select File"),SELECT_FILE);
                }
                else if(items[i].equals("Cancel")){
                    dialogInterface.dismiss();
                }
            }
        });
        builder.show();
    }

    public void addView(ImageView imageView, int width, int height) {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(width,height);
        layoutParams.setMargins(0,10,0,10);
        imageView.setLayoutParams(layoutParams);
        if(imageView.getParent() != null) {
            ((ViewGroup)imageView.getParent()).removeView(imageView); // <- fix
        }
        if(flag==0)
            layout.addView(imageView);
        else if(flag==1)
            layout1.addView(imageView);
        else if(flag==2)
            layout2.addView(imageView);


    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if(resultCode== Activity.RESULT_OK) {
            if(requestCode==REQUEST_CAMERA){
                bitmap = (Bitmap)data.getExtras().get("data");
                if(flag==0) {
                    imageView.setImageBitmap(bitmap);
                    addView(imageView, 200, 200);
                }
                else if(flag==1) {
                    imageView1.setImageBitmap(bitmap);
                    addView(imageView1, 200, 200);
                }
                else if(flag==2) {
                    imageView2.setImageBitmap(bitmap);
                    addView(imageView2, 200, 200);
                }

            }
            else if(requestCode==SELECT_FILE){
                Uri selectImageUri = data.getData();
                if(flag==0) {
                    imageView.setImageURI(selectImageUri);
                    addView(imageView, 200, 200);
                }
                else if(flag==1) {
                    imageView1.setImageURI(selectImageUri);
                    addView(imageView1, 200, 200);
                }
                else if(flag==2) {
                    imageView2.setImageURI(selectImageUri);
                    addView(imageView2, 200, 200);
                }

            }
        }

    }

}
